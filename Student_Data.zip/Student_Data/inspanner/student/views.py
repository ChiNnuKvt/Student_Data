from django.shortcuts import render , redirect
from django.http import HttpResponse
from . models import ins_student
from . forms import StudentCreate
# Create your views here.

def index(request):
    data=ins_student.objects.all()
    return render(request,"student.html",{'data':data})

def upload(req):
    upload=StudentCreate()
    if req.method=='POST':
        upload=StudentCreate(req.POST,req.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('index')
        else:
            return HttpResponse("your data is invalid")
    else:
        return render(req,"upload.html",{'upload_form':upload})

def update_data(request,st_id):
    st_id=int(st_id)
    st_sel=ins_student.objects.get(id=st_id)
    st_form=StudentCreate(request.POST or None, instance=st_sel)
    if st_form.is_valid():
        st_form.save()
        return redirect('index')
    return render(request,"upload.html",{'upload_form':st_form})

def delete_data(req,st_id):
    st_id=int(st_id)
    data_done=ins_student.objects.get(id=st_id)
    data_done.delete()
    return redirect('index')