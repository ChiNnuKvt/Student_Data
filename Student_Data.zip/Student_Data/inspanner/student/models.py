from django.db import models

# Create your models here.
class ins_student(models.Model):
    st_id=models.IntegerField()
    st_name=models.CharField(max_length=80)
    st_contact=models.IntegerField()
    st_email=models.EmailField()
    st_doj=models.DateField()
    st_course=models.CharField(max_length=15)
    st_qualification=models.CharField(max_length=15)

    def __str__(self):
        return self.st_name