from . models import ins_student
from django import forms

class StudentCreate(forms.ModelForm):
    class Meta:
        model=ins_student
        fields='__all__'
