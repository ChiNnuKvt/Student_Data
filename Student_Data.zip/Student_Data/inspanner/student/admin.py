from django.contrib import admin
from . models import ins_student
# Register your models here.
admin.site.register(ins_student)